%**************************************************************************
%**************************************************************************
% Feedback linearization applied to helicopter control 
%**************************************************************************
%**************************************************************************

%==========================================================================
% Data
%==========================================================================

% Helicopter dynamics
m = 10;
J = 0.2;
f = 0.1;
g = 9.81;

% Actuators
tau = 0.1;
Lmin = 0; Lmax = 200;  
Tmin = -0.035; Tmax = 0.035; 



%%
%==========================================================================
% Open loop simulation
%==========================================================================

% Simulation
Tsim = 30;
DTsim = 0.01;

% Input demand on the Lift
d1_step_start = 5;
d1_step_stop  = Tsim+1;
d1_step_initial_value = m*g;
d1_step_final_value = m*g*1.1;

% Input demand on the Torque
d2_step_start = 10;
d2_step_stop  = Tsim+1;
d2_step_initial_value = 0;
d2_step_final_value = 0.01;

% Simulation
sim('simulation_model_1');

% Plots
figure;
subplot(5,1,1); plot(t,Ld,t,L,'linewidth',2); grid on; legend('Ld','L');
subplot(5,1,2); plot(t,Td,t,T,'linewidth',2); grid on; legend('Td','T');
subplot(5,1,3); plot(t,gx,'linewidth',2); grid on; legend('gx');
subplot(5,1,4); plot(t,gz,'linewidth',2); grid on; legend('gz');
subplot(5,1,5); plot(t,q,'linewidth',2); grid on; legend('q');

return

%%
%==========================================================================
% I/O linearization
%==========================================================================

% Simulation
Tsim = 30;
DTsim = 0.01;

% Input demand on the second derivative of the x acceleration
d1_step_start = 5;
d1_step_stop  = Tsim+1;
d1_step_initial_value = 0;
d1_step_final_value = 2*(0.1*g)/Tsim^2;

% Input demand on the second derivative of the z acceleration
d2_step_start = 10;
d2_step_stop  = Tsim+1;
d2_step_initial_value = 0;
d2_step_final_value = 2*(g)/Tsim^2;

% Simulation
sim('simulation_model_2');

% Plots
figure;
subplot(4,1,1); plot(t,wx,'linewidth',2); grid on; legend('wx');
subplot(4,1,2); plot(t,wz,'linewidth',2); grid on; legend('wz');
subplot(4,1,3); plot(t,gx,'linewidth',2); grid on; legend('gx');
subplot(4,1,4); plot(t,gz,'linewidth',2); grid on; legend('gz');



%%
%==========================================================================
% I/O linearization and stabilization
%==========================================================================

% Simulation
Tsim = 30;
DTsim = 0.01;

% Input demand on the x acceleration
d1_step_start = 5;
d1_step_stop  = Tsim+1;
d1_step_initial_value = 0;
d1_step_final_value = 0.1*g;

% Input demand on the z acceleration
d2_step_start = 10;
d2_step_stop  = Tsim+1;
d2_step_initial_value = 0;
d2_step_final_value = g;

% Stabilizing feedback gains (PD control)
kp_gx = 0;
kd_gx = 0;
kp_gz = 0;
kd_gz = 0;

% Simulation
sim('simulation_model_3');

% Plots
figure;
subplot(5,1,1); plot(t,Ld,t,L,'linewidth',2); grid on; legend('Ld','L');
subplot(5,1,2); plot(t,Td,t,T,'linewidth',2); grid on; legend('Td','T');
subplot(5,1,3); plot(t,gx,t,gxstar,'linewidth',2); grid on; legend('gx','gxd');
subplot(5,1,4); plot(t,gz,t,gzstar,'linewidth',2); grid on; legend('gz','gzd');
subplot(5,1,5); plot(t,q,'linewidth',2); grid on; legend('q');


%%
%==========================================================================
% Velocity and position control
%==========================================================================
