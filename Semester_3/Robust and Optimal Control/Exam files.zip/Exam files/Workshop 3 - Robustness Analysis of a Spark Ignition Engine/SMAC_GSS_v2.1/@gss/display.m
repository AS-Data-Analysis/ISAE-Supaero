%%
% GSS/DISPLAY                                   Display a gss object
% ------------------------------------------------------------------
%
% Overloaded DISPLAY function for gss objects.
%
% CALL
% display(sys)
% sys
%
% INPUT ARGUMENT
% - sys: gss object.
%
% SMAC TOOLBOX - GSS LIBRARY
% See http://w3.onera.fr/smac/gss for more info!
