#------------------------------------------------------

# number of seconds in day
nbSeconds = 24*60*60
print("number of seconds in a day :")
print(nbSeconds)

# compute and print the number of seconds in a year

#------------------------------------------------------