/************************************************************)
(*                I S A E / S U P A E R O                   *)
(*                                                          *)
(*                     Xenomai Demo                         *)
(*                                                          *)
(*                                                    	    *)
(*                    Periodic Tasks                        *)
(*                                                	    *)
(*                                                          *)
(************************************************************/

// This program will run 3 Xenomai tasks: main, producer and consumer. They
// will run in parallel, while sharing some data (a counter). As a result, one
// must setup a mutex to protect this counter. There is also a semaphore, on
// which main is waiting, which will be released when the program must terminate
// (either with a signal handler or the normal duration of the program has
// elapsed).

//--< linux includes >-----------------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <termios.h>
#include <math.h>
#include <limits.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/param.h>
#include <sys/mman.h>
#include <sys/fcntl.h>
#include <sys/time.h>
//--< xenomai includes >---------------------------------------
#include <native/task.h>
#include <native/timer.h>
#include <native/queue.h>
#include <native/sem.h>
#include <native/event.h>
#include <native/mutex.h>
#include <rtdk.h>

// Macros definitions

// Priority [0..99] 0 is the lowest
#define MAIN_PRIORITY   1// // Priority of Main Task (application)

#define PRODUCER_PRIORITY   6
#define CONSUMER_PRIORITY   5

#define PRODUCER_PERIOD 10000	//  Period of task tProducer, in µs
#define CONSUMER_PERIOD 200000	// Period of task tConsumer, in µs

#define PRODUCER_CPUuse 1000	// µs
#define CONSUMER_CPUuse 50000	// µs

#define APP_DURATION 10 // seconds

#define ONE_SECOND   1e9     // Time unit for rt_functions is nanosecond

// Application global declarations
int counter;
RTIME t0,timeEnd; // t0 must be initialized in main()
// This function can be used to visualize the relative system time
// Xenomai identifiers

RT_TASK MainTask;
RT_TASK producerTask;
RT_TASK consumerTask;

RT_SEM  exitApplicationSem;
RT_MUTEX counterMutex;

void forceCPUuse(RTIME duration)
/* This function is used only for changing the execution duration of a task
   according to parameter 'duration' */
{
  RT_TASK_INFO TaskInfo;
  int cr;
  RTIME t0,tEnd;
  // Retrieve information about the current task
  cr = rt_task_inquire(rt_task_self(), &TaskInfo);// rt_task_self : current task
  // Set tEnd using the current (initial) time of the current task and 'duration'
  tEnd=TaskInfo.exectime+duration*1000;
  // Check if the current execution time reached tEnd
  do
    cr = rt_task_inquire(rt_task_self(), &TaskInfo);// update the structure TaskInfo
  while  (TaskInfo.exectime < tEnd);
}

void DisplayTaskInfo(RT_TASK task)
/* Used for displaying information about the tasks*/
{
  RT_TASK_INFO TaskInfo;
  int cr;
  
  // Retrieve information about the current task
  cr = rt_task_inquire(&task, &TaskInfo);
  if (cr == 0) {
    // Print task name, priority and execution time
    rt_printf("Task name : %s, Priority : %d, Exectime MP en µs %d \r\n", TaskInfo.name, TaskInfo.bprio, TaskInfo.exectime/1000);
    // Print information about context switches
    rt_printf("Commutations P/S : %d , Mode : %x , Context switches: %d\r\n", TaskInfo.modeswitches, TaskInfo.status,TaskInfo.ctxswitches);
  } else
    rt_printf("Error reading infos for task %d\r\n", cr);
}

RTIME t0,timeEnd; // t0 must be initialized in main()

// This function can be use to visualize the relative system time
void print_system_time(void)
{
  rt_printf("%8.3f | ",(double)(rt_timer_read()-t0)/ONE_SECOND);
}

void tProducer()
// Periodic task
// Output : data counter is incremented
// Tasks functions (entry points)
{ 
  rt_task_set_periodic(NULL, TM_NOW, PRODUCER_PERIOD * 1000);
 
  while( 1 ) {
    rt_task_wait_period(NULL);
    rt_mutex_acquire(&counterMutex, TM_INFINITE);	// timeout should be defined to ensure Task timing
    counter++; // The updated in this variable is protected by counterMutex
    rt_mutex_release(&counterMutex);

    forceCPUuse(PRODUCER_CPUuse); // Force CPU use while producing data

  }
}

void tConsumer()
// Periodic task
// Input : data counter
// Display time  and value of counter
// Tasks functions (entry points)
{ 
  int c;
  // calculate the end of execution 
  RTIME endtime = rt_timer_read() +  (APP_DURATION * ONE_SECOND); // Time in ns

  rt_task_set_periodic(NULL, TM_NOW, CONSUMER_PERIOD * 1000);

  while( 1 ) {
    rt_task_wait_period(NULL);
    rt_mutex_acquire(&counterMutex, TM_INFINITE);	// timeout should be defined to ensure Task timing
    // The reading of 'counter' is protected by counterMutex and can be done safely
    c=counter;
    rt_mutex_release(&counterMutex);
    rt_printf("counter= %d time :%8.3f  \n\r",c,(double)((rt_timer_read()-t0)/1000));
    
    forceCPUuse(CONSUMER_CPUuse); // Force CPU use while consuming data
    if( rt_timer_read() >= endtime ) // check if execution must finish
      rt_sem_v(&exitApplicationSem); // give exit semaphore to main task 

  }
}

// Termination signal handler
void terminate(int sig)
{
  rt_sem_v(&exitApplicationSem); // give exit semaphore to main task 
}

/*******************************************************************************
 *
 * main()
 *
 * Description : 
 *  A periodic task (Timer) giving semaphores to asynchronous tasks (Display & Main)
 *
 ******************************************************************************/
int main( int argc, char* argv[])
{
  //--< Environment initialization >-----------------------------------------
  setbuf(stdout, NULL);		// Disable buffering on stdout to have immediate display
  rt_print_auto_init(true);	// Perform auto-init of rt_print buffers
  atexit(rt_print_cleanup);	// Cleanup rt_print buffers at exit

  // Signal manager to stop the application 
  //	signal(SIGTERM, terminate);	// Termination signal (stop button)
  signal(SIGINT, terminate);  // Interrupt from keyboard 
  signal(SIGTERM, terminate); // Termination signal 

  // Avoids memory swapping for this program 

  mlockall(MCL_CURRENT | MCL_FUTURE);	// Avoids memory swapping for this program
  
  // global variables initialisation 
  counter=0;
  //--< Semaphores creation >------------------------------------------------
  //	rt_printf(" Creating the application semaphores .... \r\n");
  rt_sem_create(&exitApplicationSem, "exit", 0, S_FIFO); // Note the initial value of the semaphore

  //--< Mutexes creation >------------------------------------------------
  rt_printf(" Creating the application mutexes .... \r\n");
  rt_mutex_create(&counterMutex, "counterMutex");

  //--< Tasks creation >-----------------------------------------------------
  rt_printf(" Creating the application tasks .... \r\n");
	
  rt_task_shadow(&MainTask, "Main", MAIN_PRIORITY, T_FPU);	// Turn the current Linux thread into a Xenomai task
  rt_task_spawn(&producerTask, "Producer", 0 , PRODUCER_PRIORITY, T_FPU, &tProducer, NULL);
  rt_task_spawn(&consumerTask, "Consumer", 0 , CONSUMER_PRIORITY, T_FPU, &tConsumer, NULL);
	
  t0 = rt_timer_read(); // used by print_system_time() function
              
  rt_printf(" Tasks .. created and launched\r\n");
  rt_printf("\r\n");

  //--< MainTask waits on exit semaphore >-----------------------------------
  rt_sem_p(&exitApplicationSem, TM_INFINITE);
        
  timeEnd = rt_timer_read(); // used by print_system_time() function
  rt_printf(" total Duration =  %d µs ",(timeEnd-t0)/1000);
  rt_printf(" ( %f s )\r\n",(timeEnd-t0)/1000000000.0);  
  DisplayTaskInfo(producerTask);
  DisplayTaskInfo(consumerTask);

  //--< Tasks destruction >--------------------------------------------------
  rt_printf(" Deleting the tasks .... \r\n");
  rt_task_delete(&producerTask);
  rt_task_delete(&consumerTask);
  //--< Semaphores destruction >----------------------------------------------
  rt_sem_delete(&exitApplicationSem);
        
  rt_printf(" Deleting the mutexes .... \r\n");
  rt_mutex_delete(&counterMutex);

  rt_printf(" Application ..... finished --> exit\r\n");

  return(EXIT_SUCCESS);
}
